@echo off
setlocal
pushd "%~dp0"
python classical_baselines.py 20 rf %*
if errorlevel 1 goto fail
python classical_baselines.py 20 xgb %*
if errorlevel 1 goto fail
popd
exit /b 0
:fail
popd
exit /b 1
