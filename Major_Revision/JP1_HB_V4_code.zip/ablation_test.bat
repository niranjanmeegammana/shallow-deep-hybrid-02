
:: Run 1
run_ablation20.bat 200 --seed 42 --tag run01
run_ablation39.bat 200 --seed 42 --tag run01

:: Run 2
run_ablation20.bat 200 --seed 123 --tag run02
run_ablation39.bat 200 --seed 123 --tag run02

:: Run 3
run_ablation20.bat 200 --seed 456 --tag run03
run_ablation39.bat 200 --seed 456 --tag run03

:: Run 4
run_ablation20.bat 200 --seed 789 --tag run04
run_ablation39.bat 200 --seed 789 --tag run04

:: Run 5
run_ablation20.bat 200 --seed 2026 --tag run05
run_ablation39.bat 200 --seed 2026 --tag run05
