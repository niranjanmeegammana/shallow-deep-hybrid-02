# Refined Shallow-Deep Hybrid Fusion Codebase

## Contents

- All **12 original Python filenames** are retained (six fusion methods x 20- and 39-feature inputs).
- Original `runz201.bat` and `runz401.bat` filenames retained; they run six scripts each.
- `hybrid_shared.py` is a new shared implementation, required by every original script.

**Keep all scripts in the same folder** when running them. Each `sd_hybrid_*.py` remains an executable entry point.

## Setup and commands (Windows)

Install or verify `tensorflow`, `pandas`, `numpy`, `scikit-learn`, `matplotlib`, `psutil` in the Python environment used by your original experiments. No download is performed by these scripts.

```bat
python sd_hybrid_wgt_401.py 500 --seed 42 --tag run01
python sd_hybrid_concat_201.py 500 --seed 43 --tag run02
runz201.bat 500 --seed 42 --tag run01
runz401.bat 500 --seed 42 --tag run01
```

The first positional argument remains the maximum epochs (default 500). Optional arguments include `--root`, `--split`, `--batch-size`, `--scaler`, `--seed`, `--tag`, `--timing-repeats`. Use `python sd_hybrid_wgt_401.py --help` to inspect the full interface.

Paths are preserved by default:

- Root: `D:\miniconda\UNSW-NB15\testing`
- Data files: `data/unsw-nb15_training_90_5_5b_.csv`, `data/unsw-nb15_testing_90_5_5b_.csv`, `data/unsw-nb15_validation_90_5_5b_.csv`.
- Trained models: `hy_models/shadeep_hyb_..._model.keras`
- Metrics and plots: `results/shadeep_hyb_...`.

The **model name prefixes remain exactly as in your code**: `_201`/`_401`. `_401` now refers to **39 features**, not 40. The fusion method is still misspelled `substract` in the Python script filenames by design; model output IDs retain the original `subtract` spelling.

## Changes relative to the latest uploaded code

1. Excludes `id` from every 39-feature model. The script uses the 39-feature order from the final standalone `sd_hybrid_wgt_401.py` file, and the original 20-feature order for `_201` scripts.
2. Uses **MinMaxScaler** (fit on training data only) by default to match manuscript Section 3.4. Pass `--scaler standard` to reproduce the earlier standard-scaling setup; do **not** combine different scaler choices in one reported comparison.
3. Changes weighted-average fusion from `Average([0.15*S,0.85*D])` to the intended **`0.15*S + 0.85*D`**, removing the extra division by two.
4. Makes concatenation **unweighted in both feature configurations**: `[S,D]`. Previously the 20-feature script used `[0.15*S,0.85*D]` while 39-feature script used `[S,D]`.
5. Uses the original `batch_size=8` from the scripts' hyperparameter dictionaries in model.fit, rather than the earlier default batch size 32. Prediction batch size stays 32 as in the original .predict default.
6. Seeds NumPy/Python/TensorFlow (`--seed 42` default); GPU operations may still have implementation-specific nondeterminism.
7. Keeps the original **shallow(512)**, **deep(256,128,64,32,16,8,4)**, **fusion Dense(128,ReLU)->Dense(64,ReLU)->Dense(1,sigmoid)**, Adam 0.001 and binary cross-entropy, early stopping 50, trainable base subnetworks, and sigmoid threshold `>0.5`.
8. Removes unused model loading paths, unused separate base optimisers, unused learning rate scheduler declarations (they were not passed into `fit`), and cosmetic comments. A zero-rate dropout is retained for structural consistency, but it does not regularise.
9. Produces the original `.txt`, model `.keras`, `.png` plots, plus `.json` metrics, `_history.csv`, and `_predictions.csv`. The predictions CSV includes `attack_cat` when available.
10. Fixes epoch numbering to **1-based**, does not confuse requested epochs with actual completed epochs, and records additional process RSS, actual sizes, class counts, hardware, timing repetitions and model parameters.

### Behavioural changes you should document

The scaler change, weighted averaging fix, concatenation alignment, batch-size change and seeded initialisation **affect training outcomes**. Retrain all 12 models and rerun baselines under the same final protocol before comparing results. The old output names may be overwritten if you omit `--tag`. This archive does not alter your source CSV partitions, so the existing merged/balanced 90:5:5 split is still used by default. If you choose an untouched official test set, you must create verified partitions separately and supply the matching `--root`/`--split`.

### Methodology correction

The true hybrid computation is `S=f_S(x); D=f_D(x); z=Fusion(S,D); h1=ReLU(W1*z+b1) (128 units); h2=ReLU(W2*h1+b2) (64 units); yhat=sigmoid(W3*h2+b3)`. All submodels and fusion layers are **trained jointly**, not loaded as pretrained fixed predictors. Weighted averaging uses `[0.15,0.85]` only for the weighted-average method.

## Verification scope

The ZIP is syntactically compiled and structurally checked against the uploaded source scripts. **TensorFlow and your UNSW-NB15 CSVs are not available in this build environment**, so neural-network training was not executed here. Perform a short smoke run (e.g. `python sd_hybrid_wgt_401.py 2 --tag smoke`) in your configured environment before launching a full batch. Verify all 12 produce the intended output files.
