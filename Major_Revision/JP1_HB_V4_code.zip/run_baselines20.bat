@echo off
setlocal
pushd "%~dp0"
python standalone_baselines.py 20 shallow %*
if errorlevel 1 goto fail
python standalone_baselines.py 20 deep %*
if errorlevel 1 goto fail
popd
exit /b 0
:fail
popd
exit /b 1
