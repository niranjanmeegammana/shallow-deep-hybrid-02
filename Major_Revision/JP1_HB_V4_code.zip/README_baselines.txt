Standalone baseline add-on. Copy only standalone_baselines.py, run_baselines20.bat,
run_baselines39.bat to the directory containing your existing hybrid_shared.py.
Do NOT replace hybrid_shared.py or modify completed hybrid experiments.
Activate the same TensorFlow Python environment and use the same dataset root.
Run the batches sequentially:
run_baselines20.bat 200 --seed 42 --tag run01
run_baselines39.bat 200 --seed 42 --tag run01
run_baselines20.bat 200 --seed 123 --tag run02
run_baselines39.bat 200 --seed 123 --tag run02
run_baselines20.bat 200 --seed 456 --tag run03
run_baselines39.bat 200 --seed 456 --tag run03
run_baselines20.bat 200 --seed 789 --tag run04
run_baselines39.bat 200 --seed 789 --tag run04
run_baselines20.bat 200 --seed 2026 --tag run05
run_baselines39.bat 200 --seed 2026 --tag run05

Outputs go to <root>/baseline_results and <root>/baseline_models.
Results contain metrics JSON/TXT, history/prediction CSV, and graphs PNG.
Each baseline's train/validation/test split is exactly the existing CSV partitions.
The model architecture comes directly from hybrid_shared.build_models().
NOTE: training randomness affects sample order and initialization; five seeds
are not five different train/test partitions. Inference benchmark results depend
on system load; avoid concurrent runs.
