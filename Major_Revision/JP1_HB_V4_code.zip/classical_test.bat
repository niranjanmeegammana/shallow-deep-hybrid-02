
:: Run 1
run_ml20.bat --seed 42 --tag run01
run_ml39.bat --seed 42 --tag run01

:: Run 2
run_ml20.bat --seed 123 --tag run02
run_ml39.bat --seed 123 --tag run02

:: Run 3
run_ml20.bat --seed 456 --tag run03
run_ml39.bat --seed 456 --tag run03

:: Run 4
run_ml20.bat --seed 789 --tag run04
run_ml39.bat --seed 789 --tag run04

:: Run 5
run_ml20.bat --seed 2026 --tag run05
run_ml39.bat --seed 2026 --tag run05
