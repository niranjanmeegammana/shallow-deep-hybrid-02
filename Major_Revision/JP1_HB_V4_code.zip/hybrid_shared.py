"""Shared training implementation for the 12 Shallow-Deep Hybrid Fusion scripts.

Requires TensorFlow, scikit-learn, pandas, numpy, matplotlib, and psutil.
All paths are local; this module does not fetch external data or run when imported.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import platform
import random
import re
import sys
import time

import numpy as np
import pandas as pd
import psutil
from sklearn import __version__ as sklearn_version
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    confusion_matrix,
    f1_score,
    precision_recall_curve,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)
from sklearn.preprocessing import MinMaxScaler, StandardScaler

# Use an image backend that also works when run from a Windows batch file.
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# TensorFlow is imported only when a training script is executed.

DEFAULT_ROOT = Path(r"d:\miniconda\UNSW-NB15\testing")
DEFAULT_SPLIT = "_90_5_5b_"

FEATURES_20 = [
    'ct_state_ttl',
    'sload',
    'rate',
    'sttl',
    'smean',
    'dload',
    'sbytes',
    'ct_srv_dst',
    'ct_dst_src_ltm',
    'dbytes',
    'ackdat',
    'dttl',
    'ct_dst_sport_ltm',
    'dmean',
    'ct_srv_src',
    'dinpkt',
    'tcprtt',
    'dur',
    'synack',
    'sinpkt'
]
FEATURES_39 = [
    'dur',
    'spkts',
    'dpkts',
    'sbytes',
    'dbytes',
    'rate',
    'sttl',
    'dttl',
    'sload',
    'dload',
    'sloss',
    'dloss',
    'sinpkt',
    'dinpkt',
    'sjit',
    'djit',
    'swin',
    'stcpb',
    'dtcpb',
    'dwin',
    'tcprtt',
    'synack',
    'ackdat',
    'smean',
    'dmean',
    'trans_depth',
    'response_body_len',
    'ct_srv_src',
    'ct_state_ttl',
    'ct_dst_ltm',
    'ct_src_dport_ltm',
    'ct_dst_sport_ltm',
    'ct_dst_src_ltm',
    'is_ftp_login',
    'ct_ftp_cmd',
    'ct_flw_http_mthd',
    'ct_src_ltm',
    'ct_srv_dst',
    'is_sm_ips_ports'
]

FUSION_NAMES = {"wgt": "weighted_average", "concat": "concatenation", "maximum": "maximum",
                "minimum": "minimum", "multiply": "multiplication", "substract": "subtraction"}


def arguments(argv=None):
    parser = argparse.ArgumentParser(description="Train and evaluate one Shallow-Deep hybrid model")
    parser.add_argument("epochs", nargs="?", type=int, default=200,
                        help="Maximum training epochs (default: 500, as in the original scripts)")
    parser.add_argument("--seed", type=int, default=42,
                        help="Random seed for Python, NumPy and TensorFlow (default: 42)")
    parser.add_argument("--batch-size", type=int, default=8,
                        help="Training batch size (default: 8, from the original hyperparameters)")
    parser.add_argument("--scaler", choices=("minmax", "standard"), default="minmax",
                        help="Default MinMaxScaler matches the manuscript; 'standard' reproduces previous preprocessing")
    parser.add_argument("--root", type=Path, default=DEFAULT_ROOT,
                        help="Dataset/results root directory")
    parser.add_argument("--split", default=DEFAULT_SPLIT,
                        help="Suffix after 'training', 'testing' and 'validation' in CSV filenames")
    parser.add_argument("--tag", default="",
                        help="Optional unique suffix for output filenames, e.g. run01, to avoid overwriting runs")
    parser.add_argument("--timing-repeats", type=int, default=5,
                        help="Timed repeated test-set predictions following a warm-up (default: 5)")
    args = parser.parse_args(argv)
    if args.epochs < 1 or args.batch_size < 1 or args.timing_repeats < 1:
        parser.error("epochs, batch-size and timing-repeats must be positive")
    if args.tag and not re.fullmatch(r"[A-Za-z0-9_-]+", args.tag):
        parser.error("tag may only contain letters, digits, underscores or hyphens")
    return args


def set_seed(seed, tf):
    random.seed(seed)
    np.random.seed(seed)
    if hasattr(tf.keras.utils, "set_random_seed"):
        tf.keras.utils.set_random_seed(seed)
    else:
        tf.random.set_seed(seed)
    # GPU kernels may still be nondeterministic in some TensorFlow environments.


def load_partitions(args, features):
    data_dir = args.root / "data"
    paths = {part: data_dir / f"unsw-nb15_{part}{args.split}.csv"
             for part in ("training", "testing", "validation")}
    missing = [str(p) for p in paths.values() if not p.is_file()]
    if missing:
        raise FileNotFoundError("Missing dataset files:\n" + "\n".join(missing))
    frames = {part: pd.read_csv(path) for part, path in paths.items()}
    for part, frame in frames.items():
        missing_cols = sorted(set(features + ["label"]) - set(frame.columns))
        if missing_cols:
            raise ValueError(f"{part} dataset is missing columns: {missing_cols}")
        if frame.empty:
            raise ValueError(f"{part} dataset has no rows")
    X, y = {}, {}
    for part, frame in frames.items():
        # Preserve exact feature order between all three partitions.
        X[part] = frame.loc[:, features].to_numpy(dtype=np.float32, copy=True)
        y[part] = frame["label"].to_numpy(dtype=np.int32, copy=True).reshape(-1)
        if not np.isfinite(X[part]).all():
            raise ValueError(f"{part} has missing/infinite numeric features; examine preprocessing")
        if not set(np.unique(y[part])).issubset({0, 1}):
            raise ValueError(f"{part} label must contain only 0 (benign) and 1 (attack)")
        if len(np.unique(y[part])) != 2:
            raise ValueError(f"{part} must contain both binary classes for ROC AUC")
    scaler = MinMaxScaler() if args.scaler == "minmax" else StandardScaler()
    X["training"] = scaler.fit_transform(X["training"]).astype(np.float32)
    X["validation"] = scaler.transform(X["validation"]).astype(np.float32)
    X["testing"] = scaler.transform(X["testing"]).astype(np.float32)
    counts = {p: {str(k): int(n) for k, n in zip(*np.unique(y[p], return_counts=True))}
              for p in y}
    return frames, X, y, paths, counts, scaler


def build_models(tf, num_features):
    layers = tf.keras.layers
    # Keep the architecture and hyperparameters of the submitted scripts:
    # shallow: 512 / tanh; deep: 256,128,64,32,16,8,4
    # deep activations: tanh,tanh,relu,relu,relu,relu,leaky_relu.
    shallow = tf.keras.Sequential([
        layers.Input(shape=(num_features,)),
        layers.Dense(512, activation="tanh", kernel_initializer="he_normal"),
        layers.Dropout(0.0),  # 0.0 dropout from the source scripts: no regularisation effect.
        layers.Dense(1, activation="sigmoid"),
    ], name="shallow")
    deep = tf.keras.Sequential(name="deep")
    deep.add(layers.Input(shape=(num_features,)))
    hidden_sizes = [256, 128, 64, 32, 16, 8, 4]
    activations = ["tanh", "tanh", "relu", "relu", "relu", "relu", "leaky_relu"]
    for index, (units, activation) in enumerate(zip(hidden_sizes, activations)):
        deep.add(layers.Dense(units, activation=activation,
                              kernel_initializer="he_normal"))
        if index > 0:
            deep.add(layers.Dropout(0.0))  # Matches original six 0-rate layers.
    deep.add(layers.Dense(1, activation="sigmoid"))
    return shallow, deep


def build_hybrid(tf, num_features, fusion):
    layers = tf.keras.layers
    input_data = layers.Input(shape=(num_features,), name="traffic_features")
    shallow, deep = build_models(tf, num_features)
    pred_shallow = shallow(input_data)
    pred_deep = deep(input_data)
    if fusion == "wgt":
        # Correct the source's Average()([0.15*S, 0.85*D]) / 2 error.
        z = layers.Add(name="weighted_sum")([
            layers.Rescaling(scale=0.15, name="shallow_weight")(pred_shallow),
            layers.Rescaling(scale=0.85, name="deep_weight")(pred_deep),
        ])
    elif fusion == "concat":
        # Consistent unweighted concatenation in both 20- and 39-feature runs.
        z = layers.Concatenate(name="concatenation")([pred_shallow, pred_deep])
    elif fusion == "maximum":
        z = layers.Maximum(name="maximum")([pred_shallow, pred_deep])
    elif fusion == "minimum":
        z = layers.Minimum(name="minimum")([pred_shallow, pred_deep])
    elif fusion == "multiply":
        z = layers.Multiply(name="multiplication")([pred_shallow, pred_deep])
    elif fusion == "substract":
        z = layers.Subtract(name="subtraction")([pred_shallow, pred_deep])
    else:
        raise ValueError(f"Unknown fusion method: {fusion}")
    # Keep the 128/64/ReLU processing head used in every uploaded script.
    z = layers.Dense(128, activation="relu", name="fusion_dense_128")(z)
    z = layers.Dense(64, activation="relu", name="fusion_dense_64")(z)
    output = layers.Dense(1, activation="sigmoid", name="attack_probability")(z)
    hybrid = tf.keras.Model(inputs=input_data, outputs=output,
                            name=f"hybrid_{fusion}_{num_features}")
    # The original scripts compile the whole hybrid model with Adam, not
    # the individual base networks' separately declared optimisers.
    hybrid.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),
                   loss="binary_crossentropy", metrics=["accuracy"])
    return hybrid


def binary_metrics(y_true, scores):
    scores = np.asarray(scores, dtype=np.float64).reshape(-1)
    if len(y_true) != len(scores):
        raise ValueError("Prediction length does not match true label length")
    predicted = (scores > 0.5).astype(np.int32)  # Preserve the original threshold.
    cm = confusion_matrix(y_true, predicted, labels=[0, 1])
    tn, fp, fn, tp = (int(x) for x in cm.ravel())
    return {
        "accuracy": float(accuracy_score(y_true, predicted)),
        "precision": float(precision_score(y_true, predicted, zero_division=0)),
        "recall": float(recall_score(y_true, predicted, zero_division=0)),
        "f1": float(f1_score(y_true, predicted, zero_division=0)),
        "roc_auc": float(roc_auc_score(y_true, scores)),
        "average_precision": float(average_precision_score(y_true, scores)),
        "confusion_matrix": cm.tolist(),
        "true_negative": tn, "false_positive": fp,
        "false_negative": fn, "true_positive": tp,
        "false_positive_rate": float(fp / (fp + tn)) if (fp + tn) else None,
    }, predicted


def render_plots(output_prefix, history, y_test, test_scores):
    best_epoch_index = int(np.argmin(history.history["val_loss"]))
    epochs = np.arange(1, len(history.history["loss"]) + 1)
    fig, ax = plt.subplots(1, 2, figsize=(12, 5))
    ax[0].plot(epochs, history.history["accuracy"], label="Training")
    ax[0].plot(epochs, history.history["val_accuracy"], label="Validation")
    ax[0].axvline(best_epoch_index + 1, linestyle="--", label="Best val. loss")
    ax[0].set(title="Accuracy", xlabel="Epoch", ylabel="Accuracy")
    ax[0].legend()
    ax[1].plot(epochs, history.history["loss"], label="Training")
    ax[1].plot(epochs, history.history["val_loss"], label="Validation")
    ax[1].axvline(best_epoch_index + 1, linestyle="--", label="Best val. loss")
    ax[1].set(title="Binary cross-entropy loss", xlabel="Epoch", ylabel="Loss")
    ax[1].legend()
    fig.tight_layout()
    fig.savefig(str(output_prefix) + "_loss_accuracy.png", dpi=160)
    plt.close(fig)

    fpr, tpr, _ = roc_curve(y_test, test_scores)
    precision, recall, _ = precision_recall_curve(y_test, test_scores)
    roc_area = roc_auc_score(y_test, test_scores)
    ap = average_precision_score(y_test, test_scores)
    fig, ax = plt.subplots(1, 2, figsize=(12, 5))
    ax[0].plot(fpr, tpr, label=f"ROC AUC = {roc_area:.4f}")
    ax[0].plot([0, 1], [0, 1], linestyle="--", label="Chance")
    ax[0].set(xlabel="False positive rate", ylabel="True positive rate",
              title="Test ROC", xlim=(0, 1), ylim=(0, 1.02))
    ax[0].legend()
    ax[1].plot(recall, precision, label=f"AP = {ap:.4f}")
    ax[1].set(xlabel="Recall", ylabel="Precision",
              title="Test precision-recall", xlim=(0, 1), ylim=(0, 1.02))
    ax[1].legend()
    fig.tight_layout()
    fig.savefig(str(output_prefix) + "_roc_pr_curves.png", dpi=160)
    plt.close(fig)


def predict_seconds(model, data, batch_size=32):
    start = time.perf_counter()
    probabilities = model.predict(data, batch_size=batch_size, verbose=0).reshape(-1)
    return probabilities, time.perf_counter() - start


def text_report(path, result):
    tr = result["training"]
    ts = result["testing"]
    vl = result["validation"]
    bench = result["benchmark"]
    system = result["system"]
    def entry(label, value):
        return f"{label}: {value}\n"
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"{result['model_name']} Performance Metrics\n")
        f.write(entry("Features", result["feature_count"]))
        f.write(entry("Fusion", result["fusion_method"]))
        f.write(entry("Scaler", result["scaler"]))
        f.write(entry("Random Seed", result["random_seed"]))
        f.write(entry("Training Batch Size", result["batch_size"]))
        f.write(entry("Training Records", result["dataset_counts"]["training"]))
        f.write(entry("Validation Records", result["dataset_counts"]["validation"]))
        f.write(entry("Testing Records", result["dataset_counts"]["testing"]))
        f.write(entry("Epochs Requested", tr["max_epochs"]))
        f.write(entry("Last Epoch", tr["epochs_completed"]))
        f.write(entry("Early Stopping Triggered", tr["early_stopped"]))
        f.write(entry("Early Stopping Min Delta", tr["early_stopping_min_delta"]))
        f.write(entry("Early Stopping Patience", tr["early_stopping_patience"]))
        f.write(entry("Model Selection", tr["model_selection"]))
        f.write(entry("Best Validation Loss Epoch", tr["best_val_loss_epoch"]))
        f.write(entry("Training_time", tr["training_time_seconds"]))
        f.write(entry("Training Time Minutes", tr["training_time_seconds"] / 60.0))
        f.write(entry("Training Loss", tr["final_training_loss"]))
        f.write(entry("Training Accuracy", tr["final_training_accuracy"]))
        f.write(entry("Minimum Validation Loss", tr["minimum_validation_loss"]))
        f.write(entry("Maximum Validation Accuracy", tr["maximum_validation_accuracy"]))
        f.write(entry("Validation Loss", vl["loss"]))
        f.write(entry("Validation Accuracy", vl["accuracy"]))
        for metric in ("precision", "recall", "f1", "roc_auc", "average_precision", "false_positive_rate"):
            f.write(entry("Validation " + metric, vl[metric]))
        f.write(entry("Validation Confusion Matrix", vl["confusion_matrix"]))
        for metric, label in (("accuracy", "Test Accuracy"), ("precision", "Precision"),
                              ("recall", "Recall"), ("f1", "F1 Score"),
                              ("roc_auc", "ROC AUC Score"),
                              ("average_precision", "Average Precision"),
                              ("false_positive_rate", "False Positive Rate")):
            f.write(entry(label, ts[metric]))
        f.write(entry("Confusion Matrix", ts["confusion_matrix"]))
        f.write("\n# System Information\n")
        for label, metric in (("System CPU Usage Before Prediction (%)", "cpu_percent_before"),
                              ("System CPU Usage After Prediction (%)", "cpu_percent_after"),
                              ("System Memory Used Before (bytes)", "system_memory_before_bytes"),
                              ("System Memory Used After (bytes)", "system_memory_after_bytes"),
                              ("Process RSS Before Prediction (MiB)", "process_rss_before_mib"),
                              ("Process RSS After Prediction (MiB)", "process_rss_after_mib")):
            f.write(entry(label, system[metric]))
        f.write(entry("Process CPU Percent (one-core equivalent, first prediction)",
                      system["process_cpu_percent_one_core_during_first_prediction"]))
        f.write(entry("Prediction Time (first call, seconds)", bench["first_prediction_seconds"]))
        f.write(entry("Prediction Time (median of repeated runs, seconds)", bench["median_prediction_seconds"]))
        f.write(entry("Prediction Time Repetitions", bench["repetitions"]))
        f.write(entry("Per-Record Median Prediction Time (milliseconds)", bench["per_record_milliseconds"]))
        f.write(entry("Throughput (records/second)", bench["throughput_records_per_second"]))
        f.write(entry("Model Parameters", result["model_parameters"]))
        f.write(entry("Saved Model Size (KiB)", result["model_size_kib"]))


def run_experiment(fusion, feature_count, model_name, argv=None):
    args = arguments(argv)
    if feature_count not in (20, 39) or fusion not in FUSION_NAMES:
        raise ValueError("Expected feature_count=20/39 and a known fusion method")
    import tensorflow as tf
    set_seed(args.seed, tf)
    features = FEATURES_20 if feature_count == 20 else FEATURES_39
    if len(features) != feature_count or len(set(features)) != feature_count or "id" in features:
        raise ValueError("Feature list does not match the configured input dimensionality")
    frames, X, y, data_paths, class_counts, _ = load_partitions(args, features)
    (args.root / "results").mkdir(parents=True, exist_ok=True)
    (args.root / "hy_models").mkdir(parents=True, exist_ok=True)
    output_id = model_name + ("_" + args.tag if args.tag else "")
    results_prefix = args.root / "results" / output_id
    model_path = args.root / "hy_models" / (output_id + "_model.keras")
    print(f"\nModel: {model_name} | fusion={fusion} | features={feature_count}")
    print(f"Input datasets: {data_paths}")
    print(f"Split counts: {class_counts}")
    print(f"Scaling: {args.scaler} (fit on training partition only)")
    print(f"Results prefix: {results_prefix}")
    print(f"Model output: {model_path}")
    print("NOTE: Dataset partitioning is external; this script uses the supplied CSV partitions.")
    for p in [results_prefix.with_suffix(".txt"), model_path]:
        if p.exists():
            print(f"WARNING: existing output will be replaced: {p}")
    model = build_hybrid(tf, feature_count, fusion)
    model.summary()
    checkpoint = tf.keras.callbacks.ModelCheckpoint(str(model_path), monitor="val_loss",
                                                    save_best_only=True, mode="min", verbose=1)

   
    early_stopping = tf.keras.callbacks.EarlyStopping(
        monitor="val_loss",
        min_delta=0.001,
        patience=20,
        restore_best_weights=True
    )

    start = time.perf_counter()
    history = model.fit(X["training"], y["training"], batch_size=args.batch_size,
                        epochs=args.epochs, validation_data=(X["validation"], y["validation"]),
                        callbacks=[early_stopping, checkpoint], verbose=2)
    training_seconds = time.perf_counter() - start
    # ModelCheckpoint tracks the absolute minimum val_loss (no min_delta).
    # EarlyStopping uses min_delta=0.001 to decide when to stop; its restored
    # weights need not be from the same epoch as the lowest validation loss.
    # Load the exact best-loss checkpoint for ALL subsequent evaluations and
    # keep that checkpoint unchanged (do not overwrite it with model.save()).
    if not model_path.is_file():
        raise FileNotFoundError(f"Best validation-loss checkpoint was not saved: {model_path}")
    model = tf.keras.models.load_model(str(model_path))
    model_size_kib = model_path.stat().st_size / 1024.0

    process = psutil.Process(os.getpid())
    cpu_before = float(psutil.cpu_percent(interval=None))
    system_memory_before = int(psutil.virtual_memory().used)
    rss_before = process.memory_info().rss / (1024.0**2)
    process_times_before = process.cpu_times()
    test_scores, first_test_seconds = predict_seconds(model, X["testing"])
    process_times_after = process.cpu_times()
    process_cpu_seconds = ((process_times_after.user + process_times_after.system) -
                           (process_times_before.user + process_times_before.system))
    process_cpu_percent_one_core = 100.0 * process_cpu_seconds / max(first_test_seconds, 1e-12)
    cpu_after = float(psutil.cpu_percent(interval=None))
    system_memory_after = int(psutil.virtual_memory().used)
    rss_after = process.memory_info().rss / (1024.0**2)
    test_metrics, test_labels = binary_metrics(y["testing"], test_scores)
    # Warm the inference kernels on a small input, then repeat full-batch measurement.
    _ = model.predict(X["testing"][:min(32, len(X["testing"]))], batch_size=32, verbose=0)
    repeat_seconds = [predict_seconds(model, X["testing"])[1]
                      for _ in range(args.timing_repeats)]
    median_test_seconds = float(np.median(repeat_seconds))
    per_record_millis = 1000.0 * median_test_seconds / len(X["testing"])
    throughput = len(X["testing"]) / median_test_seconds
    val_scores, _ = predict_seconds(model, X["validation"])
    val_metrics, _ = binary_metrics(y["validation"], val_scores)
    validation_loss, validation_accuracy = model.evaluate(X["validation"], y["validation"],
                                                          batch_size=32, verbose=0)
    val_metrics.update(loss=float(validation_loss), accuracy=float(validation_accuracy))

    epochs_completed = len(history.history["loss"])
    best_val_loss_index = int(np.argmin(history.history["val_loss"]))
    best_val_acc_index = int(np.argmax(history.history["val_accuracy"]))
    result = {
        "model_name": model_name,
        "output_id": output_id,
        "feature_count": feature_count,
        "features": features,
        "fusion_method": FUSION_NAMES[fusion],
        "architecture": {"shallow_hidden": [512], "deep_hidden": [256,128,64,32,16,8,4],
                         "fusion_hidden": [128,64], "fusion_output": "sigmoid",
                         "trainable_base_models": True,
                         "weight_shallow": 0.15 if fusion=="wgt" else None,
                         "weight_deep": 0.85 if fusion=="wgt" else None},
        "scaler": args.scaler,
        "random_seed": args.seed,
        "batch_size": args.batch_size,
        "dataset_paths": {k: str(v) for k,v in data_paths.items()},
        "dataset_counts": class_counts,
        "training": {
            "max_epochs": args.epochs,
            "epochs_completed": epochs_completed,
            "early_stopped": bool(early_stopping.stopped_epoch > 0),
            "early_stopping_monitor": "val_loss",
            "early_stopping_min_delta": 0.001,
            "early_stopping_patience": 20,
            "model_selection": "lowest_val_loss_checkpoint",
            "best_val_loss_epoch": best_val_loss_index + 1,
            "max_val_acc_epoch": best_val_acc_index + 1,
            "minimum_validation_loss": float(np.min(history.history["val_loss"])),
            "maximum_validation_accuracy": float(np.max(history.history["val_accuracy"])),
            "final_training_loss": float(history.history["loss"][-1]),
            "final_training_accuracy": float(history.history["accuracy"][-1]),
            "training_time_seconds": training_seconds,
        },
        "validation": val_metrics,
        "testing": test_metrics,
        "benchmark": {
            "prediction_batch_size": 32,
            "first_prediction_seconds": first_test_seconds,
            "repeated_prediction_seconds": repeat_seconds,
            "median_prediction_seconds": median_test_seconds,
            "repetitions": args.timing_repeats,
            "per_record_milliseconds": per_record_millis,
            "throughput_records_per_second": throughput,
        },
        "system": {
            "cpu_percent_before": cpu_before,
            "cpu_percent_after": cpu_after,
            "system_memory_before_bytes": system_memory_before,
            "system_memory_after_bytes": system_memory_after,
            "process_rss_before_mib": rss_before,
            "process_rss_after_mib": rss_after,
            "process_cpu_time_seconds_during_first_prediction": process_cpu_seconds,
            "process_cpu_percent_one_core_during_first_prediction": process_cpu_percent_one_core,
            "platform": platform.platform(),
            "python_version": sys.version,
            "numpy_version": np.__version__,
            "pandas_version": pd.__version__,
            "scikit_learn_version": sklearn_version,
            "tensorflow_version": tf.__version__,
            "psutil_version": psutil.__version__,
            "logical_cpu_count": psutil.cpu_count(logical=True),
            "ram_total_gib": psutil.virtual_memory().total/(1024**3),
            "physical_gpus": [str(device) for device in tf.config.list_physical_devices("GPU")],
        },
        "model_parameters": int(model.count_params()),
        "model_size_kib": model_size_kib,
        "model_path": str(model_path),
    }
    # Save the full training history and per-record test outputs for later analysis.
    pd.DataFrame({"epoch": np.arange(1,epochs_completed+1),
                  **{k: v for k,v in history.history.items()}}).to_csv(
                      str(results_prefix)+"_history.csv", index=False)
    predictions = pd.DataFrame({"row_index": np.arange(len(y["testing"])),
                                "true_label": y["testing"],
                                "attack_probability": test_scores,
                                "predicted_label": test_labels})
    if "attack_cat" in frames["testing"].columns:
        predictions["attack_cat"] = frames["testing"]["attack_cat"].values
    predictions.to_csv(str(results_prefix)+"_predictions.csv", index=False)
    with open(str(results_prefix)+".json", "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)
    text_report(str(results_prefix)+".txt", result)
    render_plots(results_prefix, history, y["testing"], test_scores)
    print(f"Finished {output_id}: accuracy={test_metrics['accuracy']:.5f}, "
          f"F1={test_metrics['f1']:.5f}, ROC AUC={test_metrics['roc_auc']:.5f}")
    print(f"Results saved to: {results_prefix}.*")
    return result
