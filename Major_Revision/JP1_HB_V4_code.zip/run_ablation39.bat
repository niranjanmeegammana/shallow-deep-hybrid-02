@echo off
setlocal
pushd "%~dp0"
python ablation_experiments.py 39 concat_nohead %*
if errorlevel 1 goto fail
python ablation_experiments.py 39 subtract_nohead %*
if errorlevel 1 goto fail
python ablation_experiments.py 39 shallow_head %*
if errorlevel 1 goto fail
python ablation_experiments.py 39 deep_head %*
if errorlevel 1 goto fail
popd
exit /b 0
:fail
popd
exit /b 1
