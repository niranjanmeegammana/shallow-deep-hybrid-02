"""Train substract Shallow-Deep hybrid network with 20 input features.

Run: python sd_hybrid_substract_201.py [max_epochs] [--seed 42] [--tag run01]
Keep this script in the same folder as hybrid_shared.py.
"""
from hybrid_shared import run_experiment

if __name__ == "__main__":
    run_experiment(fusion="substract", feature_count=20, model_name="shadeep_hyb_subtract_201")
