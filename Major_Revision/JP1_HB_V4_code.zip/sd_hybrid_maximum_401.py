"""Train maximum Shallow-Deep hybrid network with 39 input features.

Run: python sd_hybrid_maximum_401.py [max_epochs] [--seed 42] [--tag run01]
Keep this script in the same folder as hybrid_shared.py.
"""
from hybrid_shared import run_experiment

if __name__ == "__main__":
    run_experiment(fusion="maximum", feature_count=39, model_name="shadeep_hyb_maximum_401")
