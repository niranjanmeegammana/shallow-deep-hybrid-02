"""Export correctly scaled, held-out UNSW-NB15 testing arrays for 20/39 features.

Requires: numpy, pandas, scikit-learn, joblib.
Reads existing _90_5_5b_ data partitions; does NOT alter their composition.
The default scaler matches the refined 12 hybrid scripts (MinMaxScaler).
Exports headerless CSV arrays, two scaler .joblib files, and a metadata JSON.

Example: python create_test_datasets.py
         python create_test_datasets.py --root D:/miniconda/UNSW-NB15/testing
"""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler, StandardScaler

DEFAULT_ROOT = Path(r"d:\miniconda\UNSW-NB15\testing")
DEFAULT_SPLIT = "_90_5_5b_"

FEATURES_20 = [
    'ct_state_ttl',
    'sload',
    'rate',
    'sttl',
    'smean',
    'dload',
    'sbytes',
    'ct_srv_dst',
    'ct_dst_src_ltm',
    'dbytes',
    'ackdat',
    'dttl',
    'ct_dst_sport_ltm',
    'dmean',
    'ct_srv_src',
    'dinpkt',
    'tcprtt',
    'dur',
    'synack',
    'sinpkt',
]

FEATURES_39 = [
    'dur',
    'spkts',
    'dpkts',
    'sbytes',
    'dbytes',
    'rate',
    'sttl',
    'dttl',
    'sload',
    'dload',
    'sloss',
    'dloss',
    'sinpkt',
    'dinpkt',
    'sjit',
    'djit',
    'swin',
    'stcpb',
    'dtcpb',
    'dwin',
    'tcprtt',
    'synack',
    'ackdat',
    'smean',
    'dmean',
    'trans_depth',
    'response_body_len',
    'ct_srv_src',
    'ct_state_ttl',
    'ct_dst_ltm',
    'ct_src_dport_ltm',
    'ct_dst_sport_ltm',
    'ct_dst_src_ltm',
    'is_ftp_login',
    'ct_ftp_cmd',
    'ct_flw_http_mthd',
    'ct_src_ltm',
    'ct_srv_dst',
    'is_sm_ips_ports',
]


def require_data(frame: pd.DataFrame, columns: list[str], name: str) -> np.ndarray:
    missing = [column for column in columns if column not in frame.columns]
    if missing:
        raise ValueError(f"{name}: missing columns: {missing}")
    data = frame.loc[:, columns].to_numpy(dtype=np.float32)
    if not np.isfinite(data).all():
        raise ValueError(f"{name}: features include NaN or infinite values")
    return data


def main() -> None:
    parser = argparse.ArgumentParser(description="Export held-out test arrays with training-only scaling")
    parser.add_argument("--root", type=Path, default=DEFAULT_ROOT, help="Parent of the data folder")
    parser.add_argument("--split", default=DEFAULT_SPLIT, help="Suffix in source filenames")
    parser.add_argument("--scaler", choices=["minmax", "standard"], default="minmax",
                        help="Match the preprocessing used by the training scripts")
    parser.add_argument("--legacy-x40", action="store_true",
                        help="Also write Xtest40 as an explicit compatibility alias containing 39 features")
    args = parser.parse_args()

    data_dir = args.root / "data"
    split = args.split
    f_train = data_dir / f"unsw-nb15_training{split}.csv"
    f_test = data_dir / f"unsw-nb15_testing{split}.csv"
    f_val = data_dir / f"unsw-nb15_validation{split}.csv"
    for file_path in (f_train, f_test, f_val):
        if not file_path.is_file():
            raise FileNotFoundError(f"Missing input CSV: {file_path}")

    train = pd.read_csv(f_train)
    test = pd.read_csv(f_test)
    validation = pd.read_csv(f_val)
    if "label" not in train.columns or "label" not in test.columns or "label" not in validation.columns:
        raise ValueError("Every dataset partition must contain the 'label' column")
    y_test = pd.to_numeric(test["label"], errors="raise").to_numpy()
    if not np.isin(y_test, [0, 1]).all():
        raise ValueError("Test labels must contain only binary values 0 and 1")
    y_test = y_test.astype(np.int64)

    assert len(FEATURES_20) == 20 and len(FEATURES_39) == 39
    assert len(set(FEATURES_20)) == 20 and len(set(FEATURES_39)) == 39
    assert "id" not in FEATURES_20 and "id" not in FEATURES_39
    assert set(FEATURES_20).issubset(FEATURES_39)

    outputs = {}
    for count, features in ((20, FEATURES_20), (39, FEATURES_39)):
        X_train = require_data(train, features, f"training ({count} features)")
        X_test = require_data(test, features, f"testing ({count} features)")
        scaler = MinMaxScaler() if args.scaler == "minmax" else StandardScaler()
        scaler.fit(X_train)  # Never fit on validation or test samples
        X_test_scaled = scaler.transform(X_test)

        output_csv = data_dir / f"unsw-nb15_Xtest{count}{split}.csv"
        scaler_file = data_dir / f"unsw-nb15_scaler{count}{split}.joblib"
        np.savetxt(output_csv, X_test_scaled, delimiter=",", fmt="%.17g")
        joblib.dump(scaler, scaler_file)
        outputs[str(count)] = {
            "features": features,
            "feature_count": len(features),
            "output_csv": str(output_csv),
            "scaler_file": str(scaler_file),
            "rows": int(X_test_scaled.shape[0]),
            "scaler": args.scaler,
        }
        print(f"Saved {X_test_scaled.shape[0]:,} x {count} -> {output_csv}")

        if count == 39 and args.legacy_x40:
            old_name = data_dir / f"unsw-nb15_Xtest40{split}.csv"
            shutil.copyfile(output_csv, old_name)
            print(f"Compatibility alias (39 columns, old name): {old_name}")

    labels_csv = data_dir / f"unsw-nb15_ytest{split}.csv"
    np.savetxt(labels_csv, y_test, delimiter=",", fmt="%d")
    metadata = {
        "source_partitions": {"training": str(f_train), "testing": str(f_test), "validation": str(f_val)},
        "source_rows": {"training": len(train), "testing": len(test), "validation": len(validation)},
        "test_label_counts": {str(v): int((y_test == v).sum()) for v in (0, 1)},
        "outputs": outputs,
        "labels_csv": str(labels_csv),
        "warning": "These outputs follow the EXISTING split; they do not convert a merged/balanced split into the original official independent UNSW-NB15 test set.",
    }
    metadata_path = data_dir / f"unsw-nb15_test_export_metadata{split}.json"
    metadata_path.write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    print(f"Saved labels: {labels_csv}")
    print(f"Saved metadata: {metadata_path}")
    print("Finished. Training and validation records were NOT included in the exported Xtest arrays.")


if __name__ == "__main__":
    main()
