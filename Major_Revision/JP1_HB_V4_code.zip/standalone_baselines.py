"""Standalone shallow/deep baselines matched to hybrid_shared.py.
Usage: python standalone_baselines.py 20 shallow 200 --seed 42 --tag run01
"""
import json, os, platform, sys, time
from pathlib import Path
import numpy as np
import pandas as pd
import psutil
from sklearn import __version__ as sklearn_version
from hybrid_shared import (arguments, set_seed, load_partitions, build_models,
    FEATURES_20, FEATURES_39, binary_metrics, predict_seconds, render_plots, text_report)


def main():
    import argparse
    p = argparse.ArgumentParser(description='Train one standalone baseline using hybrid experiment settings')
    p.add_argument('features', type=int, choices=[20,39])
    p.add_argument('model', choices=['shallow','deep'])
    args0, remaining = p.parse_known_args()
    args = arguments(remaining)
    import tensorflow as tf
    set_seed(args.seed, tf)
    features = FEATURES_20 if args0.features == 20 else FEATURES_39
    frames, X, y, paths, counts, _ = load_partitions(args, features)
    shallow, deep = build_models(tf, args0.features)
    model = shallow if args0.model == 'shallow' else deep
    model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),
                  loss='binary_crossentropy', metrics=['accuracy'])
    result_dir = args.root / 'baseline_results'
    model_dir = args.root / 'baseline_models'
    result_dir.mkdir(parents=True,exist_ok=True)
    model_dir.mkdir(parents=True,exist_ok=True)
    name = f'{args0.model}{args0.features}'
    output_id = name + (f'_{args.tag}' if args.tag else '')
    prefix = result_dir / output_id
    model_path = model_dir / (output_id+'_model.keras')
    if (result_dir / (output_id+'.json')).exists() or model_path.exists():
        raise FileExistsError(f'{output_id} already exists; use an unused --tag')
    ckpt = tf.keras.callbacks.ModelCheckpoint(str(model_path),monitor='val_loss',save_best_only=True,mode='min',verbose=1)
    stop = tf.keras.callbacks.EarlyStopping(monitor='val_loss',min_delta=0.001,patience=20,restore_best_weights=True)
    print(f'BASELINE {output_id} features={args0.features} seed={args.seed} batch={args.batch_size} scaler={args.scaler}')
    print(f'Dataset paths: {paths} counts: {counts}')
    model.summary()
    start=time.perf_counter()
    history=model.fit(X['training'],y['training'],batch_size=args.batch_size,epochs=args.epochs,
           validation_data=(X['validation'],y['validation']),callbacks=[stop,ckpt],verbose=2)
    training_seconds=time.perf_counter()-start
    model=tf.keras.models.load_model(str(model_path))
    process=psutil.Process(os.getpid())
    cpu_before=float(psutil.cpu_percent(interval=None))
    mem_before=int(psutil.virtual_memory().used)
    rss_before=process.memory_info().rss/(1024**2)
    pt_before=process.cpu_times()
    test_scores, first_seconds=predict_seconds(model,X['testing'])
    pt_after=process.cpu_times()
    process_cpu_seconds=(pt_after.user+pt_after.system)-(pt_before.user+pt_before.system)
    cpu_after=float(psutil.cpu_percent(interval=None))
    mem_after=int(psutil.virtual_memory().used)
    rss_after=process.memory_info().rss/(1024**2)
    test_metrics,test_labels=binary_metrics(y['testing'],test_scores)
    _=model.predict(X['testing'][:min(32,len(X['testing']))],batch_size=32,verbose=0)
    times=[predict_seconds(model,X['testing'])[1] for _ in range(args.timing_repeats)]
    median=float(np.median(times))
    val_scores,_=predict_seconds(model,X['validation'])
    val_metrics,_=binary_metrics(y['validation'],val_scores)
    val_loss,val_accuracy=model.evaluate(X['validation'],y['validation'],batch_size=32,verbose=0)
    val_metrics.update(loss=float(val_loss),accuracy=float(val_accuracy))
    h=history.history
    result={
        'model_name':name,'output_id':output_id,'feature_count':args0.features,'features':features,
        'fusion_method':'none','architecture':{'standalone_type':args0.model,
            'shallow_hidden':[512] if args0.model=='shallow' else [],
            'deep_hidden':[256,128,64,32,16,8,4] if args0.model=='deep' else [],
            'fusion_hidden':[],'trainable_base_models':True},
        'scaler':args.scaler,'random_seed':args.seed,'batch_size':args.batch_size,
        'dataset_paths':{k:str(v) for k,v in paths.items()},'dataset_counts':counts,
        'training':{'max_epochs':args.epochs,'epochs_completed':len(h['loss']),
           'early_stopped':bool(stop.stopped_epoch>0),'early_stopping_monitor':'val_loss',
           'early_stopping_min_delta':0.001,'early_stopping_patience':20,
           'model_selection':'lowest_val_loss_checkpoint',
           'best_val_loss_epoch':int(np.argmin(h['val_loss']))+1,
           'max_val_acc_epoch':int(np.argmax(h['val_accuracy']))+1,
           'minimum_validation_loss':float(np.min(h['val_loss'])),
           'maximum_validation_accuracy':float(np.max(h['val_accuracy'])),
           'final_training_loss':float(h['loss'][-1]),
           'final_training_accuracy':float(h['accuracy'][-1]),
           'training_time_seconds':training_seconds},
        'validation':val_metrics,'testing':test_metrics,
        'benchmark':{'prediction_batch_size':32,'first_prediction_seconds':first_seconds,
           'repeated_prediction_seconds':times,'median_prediction_seconds':median,
           'repetitions':args.timing_repeats,
           'per_record_milliseconds':1000.0*median/len(X['testing']),
           'throughput_records_per_second':len(X['testing'])/median},
        'system':{'cpu_percent_before':cpu_before,'cpu_percent_after':cpu_after,
           'system_memory_before_bytes':mem_before,'system_memory_after_bytes':mem_after,
           'process_rss_before_mib':rss_before,'process_rss_after_mib':rss_after,
           'process_cpu_time_seconds_during_first_prediction':process_cpu_seconds,
           'process_cpu_percent_one_core_during_first_prediction':100*process_cpu_seconds/max(first_seconds,1e-12),
           'platform':platform.platform(),'python_version':sys.version,
           'numpy_version':np.__version__,'pandas_version':pd.__version__,
           'scikit_learn_version':sklearn_version,'tensorflow_version':tf.__version__,
           'psutil_version':psutil.__version__,'logical_cpu_count':psutil.cpu_count(logical=True),
           'ram_total_gib':psutil.virtual_memory().total/(1024**3),
           'physical_gpus':[str(d) for d in tf.config.list_physical_devices('GPU')]},
        'model_parameters':int(model.count_params()),
        'model_size_kib':model_path.stat().st_size/1024.0,'model_path':str(model_path)}
    pd.DataFrame({'epoch':np.arange(1,len(h['loss'])+1),**h}).to_csv(str(prefix)+'_history.csv',index=False)
    pred=pd.DataFrame({'row_index':np.arange(len(y['testing'])),'true_label':y['testing'],
                       'attack_probability':test_scores,'predicted_label':test_labels})
    if 'attack_cat' in frames['testing'].columns:
        pred['attack_cat']=frames['testing']['attack_cat'].values
    pred.to_csv(str(prefix)+'_predictions.csv',index=False)
    with open(str(prefix)+'.json','w',encoding='utf-8') as f:json.dump(result,f,indent=2)
    text_report(str(prefix)+'.txt',result)
    render_plots(prefix,history,y['testing'],test_scores)
    print(f'COMPLETED {output_id}: accuracy={test_metrics["accuracy"]:.6f}, F1={test_metrics["f1"]:.6f}')
    print(f'Outputs: {prefix}.*')

if __name__=='__main__':main()
