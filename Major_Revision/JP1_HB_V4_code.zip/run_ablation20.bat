@echo off
setlocal
pushd "%~dp0"
python ablation_experiments.py 20 concat_nohead %*
if errorlevel 1 goto fail
python ablation_experiments.py 20 subtract_nohead %*
if errorlevel 1 goto fail
python ablation_experiments.py 20 shallow_head %*
if errorlevel 1 goto fail
python ablation_experiments.py 20 deep_head %*
if errorlevel 1 goto fail
popd
exit /b 0
:fail
popd
exit /b 1
