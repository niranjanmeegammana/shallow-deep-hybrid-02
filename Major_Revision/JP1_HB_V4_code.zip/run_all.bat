
:: Run 1
runz201.bat 200 --seed 42 --tag run01
runz401.bat 200 --seed 42 --tag run01

:: Run 2
runz201.bat 200 --seed 123 --tag run02
runz401.bat 200 --seed 123 --tag run02

:: Run 3
runz201.bat 200 --seed 456 --tag run03
runz401.bat 200 --seed 456 --tag run03

:: Run 4
runz201.bat 200 --seed 789 --tag run04
runz401.bat 200 --seed 789 --tag run04

:: Run 5
runz201.bat 200 --seed 2026 --tag run05
runz401.bat 200 --seed 2026 --tag run05