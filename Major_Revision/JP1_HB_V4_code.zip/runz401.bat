@echo off
setlocal EnableExtensions

REM Run from the folder containing this batch file, the six model scripts,
REM and hybrid_shared.py. Each Python script both trains and evaluates its model.
pushd "%~dp0"
if errorlevel 1 (
    echo ERROR: Cannot open the script directory.
    exit /b 1
)

where python >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python was not found. Activate your TensorFlow environment first.
    popd
    exit /b 1
)

if not exist "hybrid_shared.py" (
    echo ERROR: hybrid_shared.py must be in this folder.
    popd
    exit /b 1
)

echo ==========================================================
echo Training and testing all six 39-feature hybrid models
echo Optional arguments passed to every script: %*
echo ==========================================================

REM Preserve the original six Python script filenames and their order.
echo [1/6] Weighted averaging
python "sd_hybrid_wgt_401.py" %*
if errorlevel 1 goto :failed

echo [2/6] Concatenation
python "sd_hybrid_concat_401.py" %*
if errorlevel 1 goto :failed

echo [3/6] Maximum
python "sd_hybrid_maximum_401.py" %*
if errorlevel 1 goto :failed

echo [4/6] Minimum
python "sd_hybrid_minimum_401.py" %*
if errorlevel 1 goto :failed

echo [5/6] Multiplication
python "sd_hybrid_multiply_401.py" %*
if errorlevel 1 goto :failed

echo [6/6] Subtraction
python "sd_hybrid_substract_401.py" %*
if errorlevel 1 goto :failed

echo ==========================================================
echo SUCCESS: All six 39-feature models trained and evaluated.
echo Metrics and plots are saved by each Python script.
echo ==========================================================
popd
exit /b 0

:failed
echo ==========================================================
echo ERROR: A model failed; remaining models were not started.
echo Review the error message above and correct the cause.
echo ==========================================================
popd
exit /b 1
