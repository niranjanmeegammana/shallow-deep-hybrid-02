ABLATION ADD-ON (40 runs)

Copy ablation_experiments.py, run_ablation20.bat and run_ablation39.bat into
THE SAME FOLDER as the ORIGINAL hybrid_shared.py. Do not replace hybrid_shared.py.

Run these ten commands sequentially in the same TensorFlow environment and
with the same local UNSW-NB15 dataset files as the completed 80 experiments:

run_ablation20.bat 200 --seed 42 --tag run01
run_ablation39.bat 200 --seed 42 --tag run01
run_ablation20.bat 200 --seed 123 --tag run02
run_ablation39.bat 200 --seed 123 --tag run02
run_ablation20.bat 200 --seed 456 --tag run03
run_ablation39.bat 200 --seed 456 --tag run03
run_ablation20.bat 200 --seed 789 --tag run04
run_ablation39.bat 200 --seed 789 --tag run04
run_ablation20.bat 200 --seed 2026 --tag run05
run_ablation39.bat 200 --seed 2026 --tag run05

Each batch runs four models in sequence (40 total):
  concat_nohead: shallow + deep, concatenation, NO 128/64 dense head
  subtract_nohead: shallow + deep, subtraction, NO 128/64 dense head
  shallow_head: shallow only + 128/64 ReLU head
  deep_head: deep only + 128/64 ReLU head

Ablation output paths relative to --root (default D:\miniconda\UNSW-NB15\testing):
  ablation_results/NAME_TAG.json, .txt, _history.csv,
      _predictions.csv, _loss_accuracy.png, _roc_pr_curves.png
  ablation_models/NAME_TAG_model.keras

A unique --tag is mandatory. The code refuses to overwrite existing ablation JSON/model.
Results and baseline output folders are not touched.

The retained 128/64 head is trained end-to-end; branch-only head models are NOT
parameter-matched to the complete hybrid. Record trainable parameters.

The original hybrid_shared.py uses two output sigmoid neurons (one per branch)
before fusion and a final sigmoid. The nohead variant retains the final sigmoid.
This is a clean head-removal comparison of the exact original fusion outputs.

Run a small smoke test first:
  python ablation_experiments.py 20 concat_nohead 2 --seed 42 --tag smoke01

This package was checked for Python syntax and file conventions; no numerical
TensorFlow training or dataset-dependent test was run here.
