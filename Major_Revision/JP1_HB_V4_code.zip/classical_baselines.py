"""RF/XGBoost controls for JP1_HB_V4, using exactly hybrid_shared dataset selections.
Usage: python classical_baselines.py 39 rf --seed 123 --tag run02
       python classical_baselines.py 39 xgb --seed 123 --tag run02
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import sys
import time
import joblib
import numpy as np
import pandas as pd
from sklearn import __version__ as sklearn_version
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
    f1_score, roc_auc_score, average_precision_score, confusion_matrix,
    roc_curve, precision_recall_curve)
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# Can be installed in JP1_HB_V4 with hybrid_shared.py there, or one directory above.
HERE = Path(__file__).resolve().parent
if not (HERE / 'hybrid_shared.py').is_file() and (HERE.parent / 'hybrid_shared.py').is_file():
    sys.path.insert(0, str(HERE.parent))
from hybrid_shared import FEATURES_20, FEATURES_39, load_partitions


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def metrics(y, scores):
    predicted = (np.asarray(scores) > 0.5).astype(int)  # same threshold as hybrid_shared
    tn, fp, fn, tp = confusion_matrix(y, predicted, labels=[0, 1]).ravel()
    return dict(accuracy=float(accuracy_score(y, predicted)),
        precision=float(precision_score(y, predicted, zero_division=0)),
        recall=float(recall_score(y, predicted, zero_division=0)),
        f1=float(f1_score(y, predicted, zero_division=0)),
        roc_auc=float(roc_auc_score(y, scores)),
        average_precision=float(average_precision_score(y, scores)),
        confusion_matrix=[[int(tn), int(fp)], [int(fn), int(tp)]],
        true_negative=int(tn), false_positive=int(fp), false_negative=int(fn), true_positive=int(tp),
        false_positive_rate=float(fp / (fp + tn)),
        false_negative_rate=float(fn / (fn + tp))), predicted


def plot_curves(prefix, y, scores):
    fpr, tpr, _ = roc_curve(y, scores)
    pr, rc, _ = precision_recall_curve(y, scores)
    fig, ax = plt.subplots(figsize=(6, 5))
    ax.plot(fpr, tpr, label=f'ROC AUC {roc_auc_score(y, scores):.4f}')
    ax.plot([0, 1], [0, 1], '--', alpha=0.5)
    ax.set(xlabel='False positive rate', ylabel='True positive rate', title='Test ROC curve')
    ax.legend(); fig.tight_layout(); fig.savefig(str(prefix) + '_roc.png', dpi=180); plt.close(fig)
    fig, ax = plt.subplots(figsize=(6, 5))
    ax.plot(rc, pr, label=f'AP {average_precision_score(y, scores):.4f}')
    ax.set(xlabel='Recall', ylabel='Precision', title='Test precision–recall curve')
    ax.legend(); fig.tight_layout(); fig.savefig(str(prefix) + '_pr.png', dpi=180); plt.close(fig)


def main():
    ap = argparse.ArgumentParser(description='Classical ML controls for the hybrid fusion experiments')
    ap.add_argument('features', type=int, choices=[20, 39])
    ap.add_argument('model', choices=['rf', 'xgb'])
    ap.add_argument('--seed', type=int, default=42)
    ap.add_argument('--tag', default='run01')
    ap.add_argument('--root', type=Path, default=HERE.parent, help='Root with data/ folder (default: parent of JP1_HB_V4)')
    ap.add_argument('--split', default='_90_5_5b_')
    ap.add_argument('--scaler', choices=['minmax', 'standard'], default='minmax')
    ap.add_argument('--timing-repeats', type=int, default=5)
    ap.add_argument('--workers', type=int, default=1, help='CPU workers; 1 favors reproducibility')
    ap.add_argument('--trees', type=int, default=300)
    args = ap.parse_args()
    if not args.tag or not all(c.isalnum() or c in '_-' for c in args.tag):
        ap.error('--tag must contain letters, digits, underscores, or hyphens')
    if args.timing_repeats < 1 or args.workers < 1 or args.trees < 1:
        ap.error('timing-repeats, workers and trees must be positive')
    args.root = args.root.resolve()
    result_dir = HERE / 'classical_results'
    model_dir = HERE / 'classical_models'
    result_dir.mkdir(exist_ok=True); model_dir.mkdir(exist_ok=True)
    run_id = f'{args.model}{args.features}_{args.tag}'
    prefix = result_dir / run_id
    model_path = model_dir / f'{run_id}_model.joblib'
    if (result_dir / (run_id + '.json')).exists() or model_path.exists():
        raise FileExistsError(f'{run_id} exists already; use a new tag to prevent overwrite')
    features = FEATURES_20 if args.features == 20 else FEATURES_39
    frames, X, y, paths, counts, scaler = load_partitions(args, features)
    if args.model == 'rf':
        model = RandomForestClassifier(n_estimators=args.trees, max_depth=None,
            bootstrap=True, max_features='sqrt', random_state=args.seed, n_jobs=args.workers)
        version = sklearn_version
    else:
        try:
            import xgboost
            from xgboost import XGBClassifier
        except ImportError as exc:
            raise SystemExit('XGBoost not installed: python -m pip install xgboost') from exc
        model = XGBClassifier(n_estimators=args.trees, max_depth=6, learning_rate=0.05,
            subsample=0.9, colsample_bytree=0.9, objective='binary:logistic',
            eval_metric='logloss', tree_method='hist', random_state=args.seed,
            n_jobs=args.workers)
        version = xgboost.__version__
    print(f'RUN {run_id} | seed={args.seed} | features={args.features} | workers={args.workers}', flush=True)
    print('Dataset files:', paths, '\nCounts:', counts, flush=True)
    print('Parameters:', model.get_params(), flush=True)
    start = time.perf_counter()
    model.fit(X['training'], y['training'])
    fit_seconds = time.perf_counter() - start
    joblib.dump({'model': model, 'scaler': scaler, 'features': features}, model_path, compress=3)
    # Same held-out test set and score threshold as the neural network pipeline.
    val_scores = model.predict_proba(X['validation'])[:, 1]
    test_scores = model.predict_proba(X['testing'])[:, 1]
    val_metrics, _ = metrics(y['validation'], val_scores)
    test_metrics, test_pred = metrics(y['testing'], test_scores)
    _ = model.predict_proba(X['testing'][:min(32, len(X['testing']))])
    times = []
    for _ in range(args.timing_repeats):
        start = time.perf_counter()
        _ = model.predict_proba(X['testing'])
        times.append(time.perf_counter() - start)
    median = float(np.median(times))
    payload = {
        'model_name': f'{args.model}{args.features}', 'output_id': run_id,
        'feature_count': args.features, 'features': features,
        'fusion_method': 'none', 'architecture': {'classical_type': args.model},
        'scaler': args.scaler, 'random_seed': args.seed,
        'dataset_paths': {k: str(v) for k, v in paths.items()},
        'dataset_sha256': {k: sha256_file(v) for k, v in paths.items()},
        'dataset_counts': counts, 'model_hyperparameters': model.get_params(),
        'training': {'training_time_seconds': fit_seconds, 'training_type': 'classical_tree_ensemble',
                     'max_epochs': None, 'epochs_completed': None},
        'validation': val_metrics, 'testing': test_metrics,
        'benchmark': {'prediction_batch_size': int(len(X['testing'])),
                      'repeated_prediction_seconds': times,
                      'median_prediction_seconds': median,
                      'repetitions': args.timing_repeats,
                      'per_record_milliseconds': 1000 * median / len(X['testing']),
                      'throughput_records_per_second': len(X['testing']) / median},
        'model_parameters': None, 'model_size_kib': model_path.stat().st_size / 1024,
        'model_path': str(model_path),
        'system': {'platform': platform.platform(), 'python_version': sys.version,
                   'numpy_version': np.__version__, 'pandas_version': pd.__version__,
                   'scikit_learn_version': sklearn_version, 'model_library_version': version,
                   'workers': args.workers},
        'methodology_note': 'Identical predefined partitions and train-fitted MinMax scaling; no test-set tuning.'
    }
    # Write the predictions so all reported metrics can be independently verified.
    pred = pd.DataFrame({'row_index': np.arange(len(y['testing'])),
        'true_label': y['testing'], 'attack_probability': test_scores,
        'predicted_label': test_pred})
    if 'attack_cat' in frames['testing'].columns:
        pred['attack_cat'] = frames['testing']['attack_cat'].values
    pred.to_csv(str(prefix) + '_predictions.csv', index=False)
    imp = pd.DataFrame({'feature': features, 'importance': model.feature_importances_}).sort_values('importance', ascending=False)
    imp.to_csv(str(prefix) + '_importance.csv', index=False)
    plot_curves(prefix, y['testing'], test_scores)
    with open(str(prefix) + '.json', 'w', encoding='utf-8') as f:
        json.dump(payload, f, indent=2, default=str)
    with open(str(prefix) + '.txt', 'w', encoding='utf-8') as f:
        f.write(f'{run_id}\nSeed: {args.seed}\nTrain seconds: {fit_seconds:.4f}\n')
        f.write(json.dumps(test_metrics, indent=2) + '\n')
        f.write(f'Median test inference seconds: {median:.6f}\nModel size KiB: {payload["model_size_kib"]:.2f}\n')
    print(f'COMPLETE {run_id} accuracy={test_metrics["accuracy"]:.6f} F1={test_metrics["f1"]:.6f} '
          f'AUC={test_metrics["roc_auc"]:.6f} training_s={fit_seconds:.3f}', flush=True)
    print(f'Outputs: {prefix}.*', flush=True)

if __name__ == '__main__':
    main()
